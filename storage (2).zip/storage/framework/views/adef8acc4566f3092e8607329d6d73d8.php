<!-- Page Header Start-->
<div class="page-header">
    <div class="header-wrapper row m-0">

        <!-- Search Bar -->
        <form class="form-inline search-full col" action="#" method="get">
            <div class="form-group w-100">
                <div class="Typeahead Typeahead--twitterUsers">
                    <div class="u-posRelative">
                        <input class="demo-input Typeahead-input form-control-plaintext w-100" type="text" placeholder="Search..." name="q" autofocus>
                        <div class="spinner-border Typeahead-spinner" role="status"><span class="sr-only">Loading...</span></div>
                        <i class="close-search" data-feather="x"></i>
                    </div>
                    <div class="Typeahead-menu"></div>
                </div>
            </div>
        </form>

        <!-- Logo Section -->
        <div class="header-logo-wrapper col-auto p-0">
            <div class="logo-wrapper">
                <a href="<?php echo e(route('customer.dashboard')); ?>">
                    <img class="img-fluid" src="<?php echo e(asset('frontend/assets/images/logo/logo.png')); ?>" alt="">
                </a>
            </div>
            <div class="toggle-sidebar">
                <i class="status_toggle middle sidebar-toggle" data-feather="align-center"></i>
            </div>
        </div>

        <!-- Right Header Content -->
        <div class="nav-right col-xxl-7 col-xl-6 col-md-7 col-8 pull-right right-header p-0 ms-auto">
            <ul class="nav-menus">

                <!-- Website Link -->
                <li class="nav-item">
                    <a href="<?php echo e(url('/')); ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                        <i class="fa fa-globe"></i> Website
                    </a>
                </li>

                <!-- Theme Toggle -->
                <li>
                    <div class="mode">
                        <svg>
                            <use href="<?php echo e(asset('frontend/assets/svg/icon-sprite.svg#moon')); ?>"></use>
                        </svg>
                    </div>
                </li>

                <!-- Profile Dropdown -->
                <li class="profile-nav onhover-dropdown pe-0 py-0">
                    <div class="media profile-media">
                        <img class="b-r-10" src="<?php echo e(asset('frontend/assets/images/dashboard/profile.png')); ?>" alt="">
                        <div class="media-body">
                            <?php if(session()->has('customer_id')): ?>
                                <span><?php echo e(session('customer_name')); ?></span>
                                <p class="mb-0 font-roboto">Student <i class="middle fa fa-angle-down"></i></p>
                            <?php elseif(Auth::check()): ?>
                                <span><?php echo e(Auth::user()->name); ?></span>
                                <p class="mb-0 font-roboto">Admin <i class="middle fa fa-angle-down"></i></p>
                            <?php else: ?>
                                <span>Guest</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Dropdown Menu -->
                    <ul class="profile-dropdown onhover-show-div">
                        <?php if(session()->has('customer_id')): ?>
                            <li>
                                <a href="<?php echo e(route('customer.profile')); ?>">
                                    <i data-feather="user"></i> My Profile
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('customer.logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('customer-logout-form').submit();">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                                <form id="customer-logout-form" action="<?php echo e(route('customer.logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        <?php elseif(Auth::check()): ?>
                            <li>
                                <a href="<?php echo e(route('admin.profile')); ?>">
                                    <i data-feather="user"></i> My Profile
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('admin-logout-form').submit();">
                                    <i data-feather="log-out"></i> Logout
                                </a>
                                <form id="admin-logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>

            </ul>
        </div>

    </div>
</div>
<!-- Page Header Ends -->
<?php /**PATH D:\DSA-Binance-Trading\resources\views/StudentDashboard/header.blade.php ENDPATH**/ ?>