

<?php $__env->startSection('title', 'Verify Email - DSA Academy'); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Header section start here -->
<div class="pageheader-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="pageheader-content text-center">
                    <h2>Email Verification</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Verify Email</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Page Header section ending here -->

<!-- Verification Section -->
<div class="login-section padding-tb section-bg">
    <div class="container">
        <div class="account-wrapper">
            <h3 class="title">Enter the 4-digit code sent to your Mobile</h3>

            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('customer.verify.code')); ?>" method="POST" class="account-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="email" value="<?php echo e(session('email')); ?>">
                <div class="form-group">
                    <input type="text" name="code" class="form-control" placeholder="Enter 6-digit code" required>
                </div>
                <div class="form-group text-center">
                    <button type="submit" class="lab-btn"><span>Verify Code</span></button>
                </div>
            </form>

            
        </div>
    </div>
</div>
<!-- Verification Section Ends Here -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/emails/verify-code-page.blade.php ENDPATH**/ ?>