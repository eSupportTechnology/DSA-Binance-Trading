<?php $__env->startSection('title', 'Courses - DAS Academy'); ?>

<?php $__env->startSection('content'); ?>


</style>

<!-- Page Header section start -->
<div class="pageheader-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="pageheader-content text-center">
                    <h2>Courses</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Course Page</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Page Header section end -->

<!-- Course section start -->
<div class="course-section padding-tb section-bg">
    <div class="container">
        <div class="section-wrapper">
            
            <!-- 🔰 Ad Banner (Top Horizontal) -->
            <div class="mb-4 text-center">
                <?php if(!empty($bannerImage)): ?> 
                    <a href="<?php echo e($bannerLink ?? '#'); ?>" target="_blank">
                        <img src="<?php echo e(asset($bannerImage)); ?>" alt="Ad Banner" class="img-fluid rounded shadow-sm"
                            style="max-height: 150px; width: 100%; object-fit: cover;">
                    </a>
                <?php else: ?>
                    <div class="p-4 bg-light rounded shadow-sm border text-center">
                        <h5 class="mb-1">📢 Want your banner here?</h5>
                        <p class="mb-0">Contact us to feature your brand or announcement.</p>
                        <a href="<?php echo e(route('frontend.contact')); ?>" class="btn btn-outline-primary mt-2 btn-sm">
                            Contact Us
                        </a>
                    </div>
                <?php endif; ?>
            </div>


            <div class="row g-4 justify-content-center">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-md-6 col-12">
                        <div class="course-item">
                            <div class="course-inner">
                                <div class="course-thumb">
                                    <?php if($course->image): ?>
                                        <img src="<?php echo e(asset($course->image)); ?>" alt="course" width="320" height="190">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('frontend/assets/images/default-course.jpg')); ?>" alt="No Image" width="320" height="190">
                                    <?php endif; ?>
                                </div>
                                <div class="course-content">
                                    

                                    <a href="<?php echo e(route('frontend.Course_Details', ['id' => $course->course_id])); ?>">
                                        <h5 class="mt-2"><?php echo e($course->name); ?></h5>
                                    </a>

                                    <div class="course-details mt-3">
                                        <p><i class="icofont-video-alt"></i> <?php echo e($course->duration); ?> Lessons</p>
                                        <p><i class="icofont-globe"></i> <?php echo e(ucfirst($course->mode)); ?> Class</p>
                                    </div>


                                    <div class="course-footer mt-3 text-end">
                                        <a href="<?php echo e(route('frontend.Course_Details', ['id' => $course->course_id])); ?>" class="lab-btn-text mb-2 d-inline-block">
                                            Read More <i class="icofont-external-link"></i>
                                        </a>

                                        <div class="fw-bold" style="font-size: 22px; color: #e53935;">
                                            Rs.<?php echo e(number_format($course->total_price, 2)); ?>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            
        </div>
    </div>
</div>
<!-- Course section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/frontend/Course.blade.php ENDPATH**/ ?>