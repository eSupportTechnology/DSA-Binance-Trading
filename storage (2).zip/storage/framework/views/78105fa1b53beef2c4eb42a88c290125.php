

<?php $__env->startSection('title', 'Booking Failed - DSA Academy'); ?>

<?php $__env->startSection('content'); ?>

<!-- Failed Page Header -->
<div class="pageheader-section">
    <div class="container">
        <div class="pageheader-content text-center">
            <h2>Booking Status</h2>
        </div>
    </div>
</div>

<!-- Failed Message Section -->
<div class="login-section padding-tb section-bg">
    <div class="container text-center">
        <div class="card border-0 shadow-sm p-5 bg-white">
            <div class="container text-center mt-5">
                <h2 class="text-danger">❌ Payment Failed!</h2>
                <p>Unfortunately, your payment did not go through. Please try again or contact support if the issue persists.</p>
                <a href="<?php echo e(route('frontend.Course')); ?>" class="btn btn-warning mt-4">Try Again</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/bookings/failed.blade.php ENDPATH**/ ?>