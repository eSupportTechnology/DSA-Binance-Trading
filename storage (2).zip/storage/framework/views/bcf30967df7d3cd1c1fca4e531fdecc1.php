
<?php $__env->startSection('title', 'Manage Course Zoom Links'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Manage Zoom Links for <?php echo e($course->name); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Course Management</li>
    <li class="breadcrumb-item">Courses</li>
    <li class="breadcrumb-item active">Manage Zoom Links</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5>Zoom Links for <?php echo e($course->name); ?></h5>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#uploadZoomLinkModal">Add New Zoom Link</button>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Week/Name</th>
                                <th>Description</th>
                                <th>Zoom Link</th>
                                <th>Batches</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $zoomLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zoomLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($zoomLink->zoom_link_id); ?></td>
                                    <td><?php echo e($zoomLink->week_name); ?></td>
                                    <td><?php echo e($zoomLink->description ?? 'No Description'); ?></td>
                                    <td><a href="<?php echo e($zoomLink->zoom_link); ?>" target="_blank">Open Zoom Meeting</a></td>
                                    <td>
                                        <?php $__currentLoopData = $zoomLink->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-info"><?php echo e($batch->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editZoomLinkModal<?php echo e($zoomLink->zoom_link_id); ?>">Edit</button>

                                        <form action="<?php echo e(route('coursesZoomLinks.destroy', $zoomLink->zoom_link_id)); ?>" method="POST" style="display:inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Edit Modal -->
                                <div class="modal fade" id="editZoomLinkModal<?php echo e($zoomLink->zoom_link_id); ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?php echo e(route('coursesZoomLinks.update', $zoomLink->zoom_link_id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Edit Zoom Link</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label class="form-label">Week/Name</label>
                                                        <input type="text" name="week_name" class="form-control" value="<?php echo e($zoomLink->week_name); ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Zoom Link</label>
                                                        <input type="url" name="zoom_link" class="form-control" value="<?php echo e($zoomLink->zoom_link); ?>" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Description</label>
                                                        <textarea name="description" class="form-control"><?php echo e($zoomLink->description); ?></textarea>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="form-label">Batches</label>
                                                        <div class="row">
                                                            <?php $__currentLoopData = $course->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="col-md-6">
                                                                    <div class="form-check">
                                                                        <input type="checkbox" name="batches[]" value="<?php echo e($batch->id); ?>" class="form-check-input"
                                                                            id="editbatch<?php echo e($zoomLink->zoom_link_id); ?>_<?php echo e($batch->id); ?>"
                                                                            <?php echo e($zoomLink->batches->contains('id', $batch->id) ? 'checked' : ''); ?>>
                                                                        <label for="editbatch<?php echo e($zoomLink->zoom_link_id); ?>_<?php echo e($batch->id); ?>" class="form-check-label">
                                                                            <?php echo e($batch->name); ?>

                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-primary" type="submit">Save</button>
                                                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Upload Zoom Link Modal -->
<div class="modal fade" id="uploadZoomLinkModal" tabindex="-1" aria-labelledby="uploadZoomLinkModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('coursesZoomLinks.store', ['courseId' => $course->course_id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add New Zoom Link</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Week/Name</label>
                        <input type="text" name="week_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Zoom Link</label>
                        <input type="url" name="zoom_link" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control"></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Assign to Batches</label>
                        <div class="row">
                            <?php $__currentLoopData = $course->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input type="checkbox" name="batches[]" value="<?php echo e($batch->id); ?>" class="form-check-input" id="batch<?php echo e($batch->id); ?>">
                                        <label for="batch<?php echo e($batch->id); ?>" class="form-check-label"><?php echo e($batch->name); ?></label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="submit">Save Zoom Link</button>
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/courseZoomLinks/index.blade.php ENDPATH**/ ?>