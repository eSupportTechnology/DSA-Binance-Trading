
<?php $__env->startSection('title', 'Manage Course Recordings'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Manage Recordings for <?php echo e($course->name); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Course Management</li>
    <li class="breadcrumb-item">Courses</li>
    <li class="breadcrumb-item active">Manage Recordings</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Recordings for <?php echo e($course->name); ?></h5>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#uploadRecordingModal">Add New Recording</button>
                    </div>

                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Week/Name</th>
                                    <th>Description</th>
                                    <th>Recording Link</th>
                                    <th>Batches</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recordings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recording): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($recording->recording_id); ?></td>
                                        <td><?php echo e($recording->week_name); ?></td>
                                        <td><?php echo e($recording->description ?? 'No Description'); ?></td>
                                        <td><a href="<?php echo e($recording->recording_url); ?>" target="_blank">Open Recording</a></td>
                                        <td>
                                            <?php $__currentLoopData = $recording->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge bg-info"><?php echo e($batch->name); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($recording->recording_id); ?>">Edit</button>
                                            <form action="<?php echo e(route('coursesRecording.destroy', $recording->recording_id)); ?>" method="POST" style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>

                                    <!-- Edit Modal -->
                                    <div class="modal fade" id="editModal<?php echo e($recording->recording_id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($recording->recording_id); ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Edit Recording</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form action="<?php echo e(route('coursesRecording.update', $recording->recording_id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="modal-body">
                                                        <div class="mb-3">
                                                            <label class="form-label">Week/Name</label>
                                                            <input type="text" class="form-control" name="week_name" value="<?php echo e($recording->week_name); ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Recording URL</label>
                                                            <input type="url" class="form-control" name="recording_url" value="<?php echo e($recording->recording_url); ?>" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Description</label>
                                                            <textarea class="form-control" name="description"><?php echo e($recording->description); ?></textarea>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Assign to Batches</label>
                                                            <div class="row">
                                                                <?php $__currentLoopData = $course->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="col-md-4">
                                                                        <div class="form-check">
                                                                            <input type="checkbox" name="batches[]" value="<?php echo e($batch->id); ?>" class="form-check-input" id="editbatch<?php echo e($recording->recording_id); ?>_<?php echo e($batch->id); ?>"
                                                                                <?php echo e($recording->batches->contains($batch->id) ? 'checked' : ''); ?>>
                                                                            <label for="editbatch<?php echo e($recording->recording_id); ?>_<?php echo e($batch->id); ?>" class="form-check-label"><?php echo e($batch->name); ?></label>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary">Update</button>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Edit Modal -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Upload Recording Modal -->
    <div class="modal fade" id="uploadRecordingModal" tabindex="-1" aria-labelledby="uploadRecordingModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadRecordingModalLabel">Add New Recording</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('coursesRecording.store', ['courseId' => $course->course_id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Week/Name</label>
                            <input type="text" class="form-control" name="week_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Recording URL</label>
                            <input type="url" class="form-control" name="recording_url" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Assign to Batches</label>
                            <div class="row">
                                <?php $__currentLoopData = $course->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="batches[]" value="<?php echo e($batch->id); ?>" class="form-check-input" id="batch<?php echo e($batch->id); ?>">
                                            <label for="batch<?php echo e($batch->id); ?>" class="form-check-label"><?php echo e($batch->name); ?></label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Recording</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/courseRecordings/index.blade.php ENDPATH**/ ?>