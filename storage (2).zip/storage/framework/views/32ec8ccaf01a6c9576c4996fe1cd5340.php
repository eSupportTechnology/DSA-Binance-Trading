

<?php $__env->startSection('title', 'Pending Orders'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Pending Orders</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Orders</li>
    <li class="breadcrumb-item active">Pending</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header bg-warning text-white">
            <h5 class="mb-0">Course Bookings</h5>
        </div>

        <div class="card-body">
            <ul class="nav nav-tabs mb-3" id="bookingTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending"
                        type="button" role="tab">Bank Transfer - Pending</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="card-tab" data-bs-toggle="tab" data-bs-target="#card"
                        type="button" role="tab">Card - Confirmed</button>
                </li>
            </ul>

            <div class="tab-content" id="bookingTabsContent">
                <!-- Tab 1: Bank Transfer - Pending -->
                <div class="tab-pane fade show active" id="pending" role="tabpanel">
                    <?php echo $__env->make('AdminDashboard.orders.partials.booking-table', ['bookings' => $pendingBookings], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <!-- Tab 2: Card - Confirmed -->
                <div class="tab-pane fade" id="card" role="tabpanel">
                    <?php echo $__env->make('AdminDashboard.orders.partials.booking-table', ['bookings' => $cardConfirmedBookings], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/orders/pending.blade.php ENDPATH**/ ?>