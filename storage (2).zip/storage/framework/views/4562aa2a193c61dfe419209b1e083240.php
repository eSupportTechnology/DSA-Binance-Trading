

<?php $__env->startSection('title', 'Edit Batch'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Edit Batch</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.batches.index')); ?>">Batches</a></li>
    <li class="breadcrumb-item active">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h5>Edit Batch - <?php echo e($batch->name); ?></h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.batches.update', $batch->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="course_id" class="form-label">Course</label>
                    <select name="course_id" class="form-control" required>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->course_id); ?>" <?php echo e($batch->course_id == $course->course_id ? 'selected' : ''); ?>>
                                <?php echo e($course->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="name" class="form-label">Batch Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($batch->name); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="start_date" class="form-label">Start Date</label>
                    <input type="date" name="start_date" class="form-control" value="<?php echo e($batch->start_date); ?>" required>
                </div>

                <div class="text-end">
                    <a href="<?php echo e(route('admin.batches.index')); ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-success">Update Batch</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/batches/edit.blade.php ENDPATH**/ ?>