

<?php $__env->startSection('title', 'Old Student Registration - DSA Academy'); ?>

<?php $__env->startSection('content'); ?>

<!-- Page Header section start here -->
<div class="pageheader-section">
    <div class="container">
        <div class="pageheader-content text-center">
            <h2>Old Student Registration</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('frontend.home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Old Student Sign Up</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Page Header section ending here -->

<!-- Old Student Registration Section -->
<div class="login-section padding-tb section-bg">
    <div class="container">
        <div class="account-wrapper">
            <h3 class="title">Welcome Back, Student</h3>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <form class="account-form" action="<?php echo e(route('customer.old.register.submit')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" placeholder="Student ID" name="student_id" value="<?php echo e(old('student_id')); ?>">
                </div>
                <div class="form-group">
                    <input type="text" placeholder="Full Name" name="name" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                    <input type="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                </div>
                <div class="form-group">
                    <input type="text" placeholder="Contact Number" name="contact_number" value="<?php echo e(old('contact_number')); ?>">
                </div>
                <div class="form-group">
                    <input type="password" placeholder="Password" name="password">
                </div>
                <div class="form-group">
                    <input type="password" placeholder="Confirm Password" name="password_confirmation">
                </div>
                <div class="form-group">
                    <button class="lab-btn"><span>Register as Old Student</span></button>
                </div>
            </form>

            <div class="account-bottom text-center mt-3">
                <span>New Student? <a href="<?php echo e(route('customer.register')); ?>">Register here</a></span>
            </div>
        </div>
    </div>
</div>
<!-- Old Student Registration Section Ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/frontend/old-register.blade.php ENDPATH**/ ?>