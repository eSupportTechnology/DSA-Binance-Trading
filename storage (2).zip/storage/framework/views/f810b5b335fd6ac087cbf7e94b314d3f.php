<div class="table-responsive">
    <table class="table table-bordered text-center align-middle">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Student</th>
                <th>Course</th>
                <th>Payment</th>
                <th>Method</th>
                <th>Transfer Date</th>
                <th>Receipt</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($booking->customer->name ?? 'N/A'); ?></td>
                    <td><?php echo e($booking->course->name ?? 'N/A'); ?></td>
                    <td><?php echo e(ucfirst($booking->payment_status)); ?></td>
                    <td><?php echo e($booking->payment_method); ?></td>
                    <td><?php echo e($booking->transfer_date ?? 'N/A'); ?></td>
                    <td>
                        <?php if($booking->receipt_path): ?>
                            <a href="<?php echo e(route('admin.orders.show', $booking->id)); ?>" class="btn btn-sm btn-info">View</a>
                        <?php else: ?>
                            <span class="text-muted">No Receipt</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge bg-warning"><?php echo e($booking->status); ?></span></td>
                    <td>
                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateBookingModal<?php echo e($booking->id); ?>">Process</button>
                    </td>
                </tr>

                <!-- Modal -->
                <div class="modal fade" id="updateBookingModal<?php echo e($booking->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form action="<?php echo e(route('admin.orders.updateBooking', $booking->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Process Booking</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>Customer:</strong> <?php echo e($booking->customer->name); ?></p>
                                    <p><strong>Course:</strong> <?php echo e($booking->course->name); ?></p>

                                    <?php if($booking->receipt_path): ?>
                                        <p><strong>Receipt:</strong> <a href="<?php echo e(asset('storage/' . $booking->receipt_path)); ?>" target="_blank">View</a></p>
                                    <?php endif; ?>

                                    <div class="mb-3">
                                        <label class="form-label">Payment Status</label>
                                        <select name="status" class="form-control">
                                            <option value="Pending" <?php echo e($booking->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                            <option value="Half" <?php echo e($booking->status == 'Half' ? 'selected' : ''); ?>>Half</option>
                                            <option value="Confirmed" <?php echo e($booking->status == 'Confirmed' ? 'selected' : ''); ?>>Confirmed</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Assign Batch</label>
                                        <select name="batch_id" class="form-control">
                                            <option value="">-- Select Batch --</option>
                                            <?php $__currentLoopData = $booking->course->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($batch->id); ?>" <?php echo e($booking->customer->batch_id == $batch->id ? 'selected' : ''); ?>>
                                                    <?php echo e($batch->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-success">Update</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-muted">No records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/orders/partials/booking-table.blade.php ENDPATH**/ ?>