

<?php $__env->startSection('title', 'Edit VIP Package'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Edit VIP Package</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('vip-packages.index')); ?>">VIP Packages</a></li>
    <li class="breadcrumb-item active">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>Edit Package: <strong><?php echo e($vipPackage->title); ?></strong></h5>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('vip-packages.update', $vipPackage->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Title -->
                <div class="form-group mb-3">
                    <label>Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $vipPackage->title)); ?>" required>
                </div>

                <!-- Price -->
                <div class="form-group mb-3">
                    <label>Price (Rs.) <span class="text-danger">*</span></label>
                    <input type="number" name="price" class="form-control" value="<?php echo e(old('price', $vipPackage->price)); ?>" required>
                </div>

                <!-- Description -->
                <div class="form-group mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="4"><?php echo e(old('description', $vipPackage->description)); ?></textarea>
                </div>

                <!-- Current Image -->
                <?php if($vipPackage->image): ?>
                <div class="form-group mb-3">
                    <label>Current Image:</label><br>
                    <img src="<?php echo e(asset('storage/' . $vipPackage->image)); ?>" width="120" class="img-thumbnail">
                </div>
                <?php endif; ?>

                <!-- Image Upload -->
                <div class="form-group mb-3">
                    <label>Upload New Image</label>
                    <input type="file" name="image" class="form-control">
                    <small class="text-muted">Leave blank to keep current image.</small>
                </div>

                <!-- Status -->
                <div class="form-group mb-4">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="active" <?php echo e($vipPackage->status === 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e($vipPackage->status === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>

                <!-- Submit -->
                <div class="form-group text-center">
                    <button class="btn btn-success">Update Package</button>
                    <a href="<?php echo e(route('vip-packages.index')); ?>" class="btn btn-secondary">Back</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/vip_packages/edit.blade.php ENDPATH**/ ?>