<!-- resources/views/AdminDashboard/batches/index.blade.php -->


<?php $__env->startSection('title', 'Batches'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>All Batches</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Course Management</li>
    <li class="breadcrumb-item active">Batches</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h5>Batch List</h5>
            <a href="<?php echo e(route('admin.batches.create')); ?>" class="btn btn-primary">+ Add Batch</a>
        </div>

        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Course</th>
                        <th>Batch Name</th>
                        <th>Start Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($batch->course->name ?? 'N/A'); ?></td>
                        <td><?php echo e($batch->name); ?></td>
                        <td><?php echo e($batch->start_date); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.batches.edit', $batch->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                            <form action="<?php echo e(route('admin.batches.destroy', $batch->id)); ?>" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/batches/index.blade.php ENDPATH**/ ?>