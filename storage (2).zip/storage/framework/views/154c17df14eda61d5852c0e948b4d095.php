
<?php $__env->startSection('title', 'All Courses'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>All Courses</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Course Management</li>
    <li class="breadcrumb-item active">All Courses</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Course List</h5>
                        <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-primary">Add New Course</a>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Course Name</th>
                                    <th>Duration (Days)</th>
                                    <th>Total Price (Rs.)</th>
                                    <th>First Payment (Rs.)</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($course->course_id); ?></td>
                                        <td>
                                            <?php if($course->image): ?>
                                                <img src="<?php echo e(asset($course->image)); ?>" alt="Course Image" width="70" height="70" align="center">
                                            <?php else: ?>
                                                No Image
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($course->name); ?></td>
                                        <td><?php echo e($course->duration); ?></td>
                                        <td><?php echo e($course->total_price); ?></td>
                                        <td><?php echo e($course->first_payment); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('courses.show', $course->course_id)); ?>" class="btn btn-info btn-sm">View</a>
                                            <a href="<?php echo e(route('courses.edit', $course->course_id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(route('courses.destroy', $course->course_id)); ?>" method="POST" style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/courses/index.blade.php ENDPATH**/ ?>