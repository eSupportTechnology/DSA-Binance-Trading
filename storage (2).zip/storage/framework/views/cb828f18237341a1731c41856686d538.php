

<?php $__env->startSection('title', 'All Employees'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Employee Management</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Settings</li>
    <li class="breadcrumb-item active">Employees</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Employees List</h5>
            <a href="<?php echo e(route('admin.employees.create')); ?>" class="btn btn-primary btn-sm">+ Add New Employee</a>
        </div>

        <div class="card-body table-responsive">
            <table class="table table-bordered text-center align-middle">
                <thead class="table-light">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($employee->name); ?></td>
                            <td><?php echo e($employee->email); ?></td>
                            <td><?php echo e(ucfirst($employee->role ?? 'N/A')); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($employee->status ? 'success' : 'danger'); ?>">
                                    <?php echo e($employee->status ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td class="d-flex justify-content-center gap-2">
                                <a href="<?php echo e(route('admin.employees.edit', $employee->id)); ?>" class="btn btn-sm btn-info">Edit</a>

                                <form action="<?php echo e(route('admin.employees.destroy', $employee->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this employee?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-muted">No employees found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div class="mt-3">
                <?php echo e($employees->links()); ?> <!-- Pagination -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/employees/index.blade.php ENDPATH**/ ?>