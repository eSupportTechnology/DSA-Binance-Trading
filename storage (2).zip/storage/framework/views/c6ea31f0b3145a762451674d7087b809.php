<?php $__env->startSection('title', 'Home - Edukon'); ?>

<?php $__env->startSection('content'); ?>


<?php
    function getYoutubeVideoId($url) {
        if (preg_match('/(?:youtu\.be\/|youtube\.com(?:\/embed\/|\/watch\?v=|\/v\/))([^\&\?\/]+)/', $url, $matches)) {
            return $matches[1];
        }
        return null;
    }
?>



<style>
/* Enroll Section */
.enroll-section {
    position: fixed; /* Keeps the button fixed */
    top: 50%; /* Center vertically */
    right: 20px; /* Align to the right */
    transform: translateY(-50%); /* Perfect vertical alignment */
    display: flex; /* Flexbox to align */
    flex-direction: column; /* Vertical alignment */
    align-items: center; /* Center content horizontally */
    justify-content: center; /* Center content vertically */
    z-index: 1000; /* Keep on top of other content */
}

/* Enroll Button */
.enroll-btn {
    background-color:rgb(12, 102, 199); /* Button color (blue) */
    color:rgb(255, 255, 255); /* Text color */
    font-size: 14px; /* Font size */
    font-weight: bold; /* Bold text */
    padding: 6px 15px; /* Space inside the button */
    border-radius: 20px; /* Rounded corners */
    text-decoration: none; /* Remove underline */
    cursor: pointer; /* Pointer cursor on hover */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Add shadow */
    transition: all 0.3s ease; /* Smooth hover animation */
    writing-mode: vertical-rl; /* Rotate the text vertically */
    text-orientation: upright; /* Ensure letters stay upright */
}

/* Hover Effect for Button */
.enroll-btn:hover {
    background-color:rgb(21, 133, 252); /* Darker blue on hover */
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2); /* Add shadow on hover */
}
.h6 {
    position: relative;
    animation: fall 2s ease-in-out;
}

.course-price-box {
    background-color: #ee1831; /* Bright red */
    color: #fff;
    padding: 6px 15px;
    display: inline-block;
    border-radius: 5px;
    font-weight: 600;
    font-size: 16px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.cbs-content-list {
    margin-top: 200px;
}

.meta-post i {
    color: #ee1831 !important;   /* Force red */
    opacity: 1 !important;       /* Ensure visibility */
    visibility: visible !important;
    transition: none !important; /* Cancel any transition effects */
}

@keyframes fall{
    0%{
        transform: translatey(-100%);
        opacity: 0;
    }
    100%{
        transform: translatey(0);
        opacity: 1;
    }
}
.h2{
    animation: typing 4s steps(30, end), blink-caret 0.5s step-end infinite;
}
@keyframes typing{
    from{
        width: 0;
    }
    to{
        width: 100%;
     }
}
@keyframes blink-caret{
    from,to{
        border-color: transparent;
    }
    50%{
        border-color: black;
    }
}
/* Responsive Design */
@media (max-width: 768px) {
    .enroll-section {
        right: 10px; /* Adjust for smaller screens */
    }

    .enroll-btn {
        font-size: 14px; /* Smaller font size */
        padding: 8px 15px; /* Adjust padding */
    }
}
</style>


<style>
    .vip-btn {
        background-color: #ed3532;
        font-weight:bold;
        color: #000;
        transition: background 0.3s ease;
    }

    .vip-btn:hover {
        background-color: #c8232c;
        color: #fff;
    }
</style>

    <!-- banner section start here -->
    <section class="banner-section style-1" style="background:#eddddd">
        <div class="container">
            <div class="section-wrapper">
                <div class="row align-items-center">
                    <!-- Text Area -->
                    <div class="col-xxl-6 col-xl-7 col-lg-11">
                        <div class="banner-content">
                            <h6 class="subtitle text-uppercase fw-medium mt-5" style="color:#ee1831;">Empowering Education</h6>
                            <h2 class="title" style="color:#1b2954;">
                                <span class="d-lg-block">DSA Academy</span>
                                Learn The Skills That <span class="d-lg-block">Transform Your Life</span>
                            </h2>
                            <p class="desc">
                                Join 10,000+ students across Sri Lanka.<br>
                                Gain real-world skills through online and physical classes.<br>
                                Start your journey with DSA today!
                            </p>
                            
                        </div>
                    </div>

                    <!-- Image Area -->
                    <div class="col-xxl-6 col-xl-5 d-none d-xl-block"
                        style="background-image: url('<?php echo e(asset('frontend/assets/images/logo.png')); ?>');
                            background-size: contain;
                            background-repeat: no-repeat;
                            background-position: center;
                            min-height: 500px;">
                    </div>
                </div>
            </div>
        </div>

        <!-- Optional: Floating Stats -->
        <div class="cbs-content-list d-none d-lg-block mt-4">
            <ul class="lab-ul">
                <li class="ccl-shape shape-1"><a href="#">10,000+ Students Trained</a></li>
                <li class="ccl-shape shape-2"><a href="#">25+ Certified Courses</a></li>
                <li class="ccl-shape shape-3"><a href="#">95% Student Satisfaction</a></li>
                <li class="ccl-shape shape-4"><a href="#">Experienced Trainers</a></li>
                <li class="ccl-shape shape-5"><a href="#">Flexible Learning Modes</a></li>
            </ul>
        </div>
    </section>
    <!-- banner section ending here -->


    <!-- Achievement section start here -->
    <div class="achievement-section padding-tb">
        <div class="container">
            <!-- Stats Top -->
            <div class="section-header text-center">
                <span class="subtitle" style="color:#ed3532;">START TO SUCCESS</span>
                <h2 class="title" style="color:#1b2954;">Achieve Your Goals With DSA Academy</h2>
            </div>

            <div class="section-wrapper">
                <div class="counter-part mb-5">
                    <div class="row g-4 row-cols-lg-4 row-cols-sm-2 row-cols-1 justify-content-center">
                        <div class="col">
                            <div class="count-item text-center">
                                <h2><span class="count"><?php echo e($stats['experience']); ?></span>+</h2>
                                <p>Years of Education Experience</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="count-item text-center">
                                <h2><span class="count"><?php echo e($stats['students']); ?></span>+</h2>
                                <p>Students Trained</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="count-item text-center">
                                <h2><span class="count"><?php echo e($stats['teachers']); ?></span>+</h2>
                                <p>Expert Instructors</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="count-item text-center">
                                <h2><span class="count"><?php echo e($stats['courses']); ?></span>+</h2>
                                <p>Certified Courses</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- YouTube Section -->
                <div class="achieve-part mt-4">
                    <div class="row g-4 row-cols-1 row-cols-md-2 row-cols-lg-3">
                        <?php $__empty_1 = true; $__currentLoopData = $youtubeVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $videoId = getYoutubeVideoId($video->youtube_url);
                                $thumbnailUrl = $video->thumbnail
                                    ? asset('storage/' . $video->thumbnail)
                                    : ($videoId ? 'https://img.youtube.com/vi/' . $videoId . '/hqdefault.jpg' : null);
                            ?>

                            <div class="col">
                                <div class="p-3 bg-white shadow-sm rounded-3 d-flex align-items-center h-100" style="min-height: 200px;">
                                    <!-- Thumbnail -->
                                    <?php if($thumbnailUrl): ?>
                                        <div class="me-3" style="width: 200px; height: 150px; flex-shrink: 0;">
                                            <a href="<?php echo e($video->youtube_url); ?>" target="_blank">
                                                <img src="<?php echo e($thumbnailUrl); ?>" alt="<?php echo e($video->title); ?>" class="w-100 h-100 object-fit-cover rounded-2">
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Text Content -->
                                    <div class="flex-grow-1">
                                        <h6 class="mb-2 text-dark fw-bold"><?php echo e(Str::limit($video->title, 60)); ?></h6>
                                        <a href="<?php echo e($video->youtube_url); ?>" target="_blank" class="btn btn-sm btn-outline-danger">
                                            Watch on YouTube <i class="icofont-play-alt-1"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12 text-center">
                                <p class="text-muted">No YouTube videos found.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    
    
    
    <!-- About DSA Academy Section -->
    <div class="skill-section padding-tb section-bg ">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <!-- Left Column: About Content -->
                <div class="col-lg-5 col-12">
                    <div class="section-header mb-4">
                        <span class="subtitle text-danger">About DSA Academy</span>
                        <h2 class="title" style="color:#1b2954;">Empowering Your Future With Practical Skills</h2>
                        <p class="mt-3">
                            DSA Academy is a leading education provider focused on delivering high-quality, practical training in IT, business, and professional development. 
                            We empower individuals through hands-on learning, expert instructors, and industry-recognized certifications—ensuring you're ready for the real world.
                        </p>
                        <a href="#courses" class="lab-btn mt-4"><span>Explore Our Courses</span></a>
                    </div>
                </div>

                <!-- Right Column: Highlights -->
                <div class="col-lg-7 col-12">
                    <div class="section-wrapper">
                        <div class="row g-4 justify-content-center row-cols-sm-2 row-cols-1">
                            <div class="col">
                                <div class="skill-item">
                                    <div class="skill-inner d-flex align-items-start">
                                        <div class="skill-thumb me-3 mb-2">
                                            <img src="<?php echo e(asset('frontend/assets/images/instructor.png')); ?>" alt="Skilled Instructors" style="width:50px;">
                                        </div>
                                        <div class="skill-content">
                                            <h5>Experienced Instructors</h5>
                                            <p>Learn from professionals with real-world experience.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="skill-item">
                                    <div class="skill-inner d-flex align-items-start">
                                        <div class="skill-thumb me-3 mb-4">
                                            <img src="<?php echo e(asset('frontend/assets/images/cetificate.png')); ?>" alt="Certificates" style="width:50px;">
                                        </div>
                                        <div class="skill-content">
                                            <h5>Recognized Certifications</h5>
                                            <p>Stand out with industry-recognized qualifications.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="skill-item">
                                    <div class="skill-inner d-flex align-items-start">
                                        <div class="skill-thumb me-3 mb-3">
                                            <img src="<?php echo e(asset('frontend/assets/images/world-grid.png')); ?>" alt="Online Classes" style="width:50px;">
                                        </div>
                                        <div class="skill-content">
                                            <h5>Flexible Learning</h5>
                                            <p>Choose online or in-person learning modes.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="skill-item">
                                    <div class="skill-inner d-flex align-items-start">
                                        <div class="skill-thumb me-2 mb-4">
                                            <img src="<?php echo e(asset('frontend/assets/images/skill/skill.gif')); ?>" alt="Practical Training" style="width:50px;">
                                        </div>
                                        <div class="skill-content">
                                            <h5>Practical Approach</h5>
                                            <p>Hands-on projects to apply what you learn.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About DSA Academy Section -->



    <!-- Feedback Slider Section -->
    <div class="student-feedbak-section padding-tb shape-img mb-80">
        <div class="container">
            <div class="section-header text-center mt-4">
                <span class="subtitle">What Students Say</span>
                <h2 class="title">Community Feedback</h2>
            </div>

            <div class="swiper myReviewSwiper">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="stu-feed-item p-4 border rounded bg-white shadow-sm text-center h-100 d-flex flex-column justify-content-between">
                                
                                <!-- Top: Student Image -->
                                <div class="mb-4">
                                    <img src="<?php echo e($review->image ? asset('storage/' . $review->image) : asset('frontend/assets/images/default-user.png')); ?>"
                                        alt="<?php echo e($review->student_name); ?>"
                                        class="rounded-circle mx-auto d-block shadow"
                                        style="width: 100px; height: 100px; object-fit: cover;">
                                </div>

                                <!-- Bottom: Name & Rating -->
                                <div>
                                    <h6 class="mb-2"><?php echo e($review->student_name); ?></h6>
                                    <div class="ratting">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <i class="icofont-ui-rating<?php echo e($i <= $review->rating ? '' : '-blank'); ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Swiper Arrows -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
    </div>

    <!-- Swiper Init -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            new Swiper(".myReviewSwiper", {
                slidesPerView: 1,
                spaceBetween: 30,
                loop: true,
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                breakpoints: {
                    768: { slidesPerView: 2 },
                    1200: { slidesPerView: 3 }
                }
            });
        });
    </script>
    <!-- student feedbak section ending here -->



    <!-- blog section start here -->
    <div class="blog-section padding-tb section-bg">
        <div class="container">
            <div class="section-header text-center">
                <span class="subtitle">FROM OUR BLOG POSTS</span>
                <h2 class="title">More Articles From Resource Blog</h2>
            </div>
            <div class="section-wrapper">
                <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 justify-content-center g-4">

                    <?php $__empty_1 = true; $__currentLoopData = $latestBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col">
                            <div class="post-item">
                                <div class="post-inner">
                                    
                                    <!-- Media (Image or Video) -->
                                    <div class="post-thumb" style="height: 250px; overflow: hidden;">
                                        <?php if($blog->media_type === 'image' && $blog->media_path): ?>
                                            <a href="#">
                                                <img src="<?php echo e(asset('storage/' . $blog->media_path)); ?>" alt="<?php echo e($blog->title); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                            </a>
                                        <?php elseif($blog->media_type === 'video' && $blog->media_path): ?>
                                            <video width="100%" height="250" controls style="object-fit: cover;">
                                                <source src="<?php echo e(asset('storage/' . $blog->media_path)); ?>" type="video/mp4">
                                                Your browser does not support the video tag.
                                            </video>
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend/assets/images/blog/default.jpg')); ?>" alt="default blog" style="width: 100%; height: 100%; object-fit: cover;">
                                        <?php endif; ?>
                                    </div>

                                    <!-- Content -->
                                    <div class="post-content">
                                        <a href="#"><h4><?php echo e(Str::limit($blog->title, 60)); ?></h4></a>

                                        <div class="meta-post">
                                            <ul class="lab-ul">
                                                <i class="icofont-ui-user p-2" ></i>DSA Academy
                                                <i class="icofont-calendar m-3"></i><?php echo e($blog->created_at->format('F d, Y')); ?>

                                            </ul>
                                        </div>

                                        <p><?php echo e(Str::limit(strip_tags($blog->content), 120)); ?></p>
                                    </div>

                                    <!-- Footer -->
                                    <div class="post-footer">
                                        <div class="pf-left">
                                            <a href="#" class="lab-btn-text">
                                                Read more <i class="icofont-external-link"></i>
                                            </a>
                                        </div>
                                        <div class="pf-right">
                                            <i class="icofont-comment"></i>
                                            <span class="comment-count">0</span> 
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">
                            <p class="text-muted">No blog posts found.</p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <!-- blog section ending here -->


    <!-- Promotional Banner Slider Section -->
    <div class="achievement-section padding-tb section-bg">
        <div class="container">
            <div class="section-header text-center mb-4">
                <span class="subtitle" style="color:#ed3532;">Special Promotions</span>
                <h2 class="title" style="color:#1b2954;">Latest Offers & Announcements</h2>
            </div>

            <div class="swiper myAdBannerSwiper">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="banner-item shadow-sm rounded overflow-hidden">
                                <img src="<?php echo e(asset('storage/' . $banner->image)); ?>"
                                    alt="Banner Image"
                                    class="w-100"
                                    style="height: 500px; object-fit: cover;">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Navigation -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
    </div>

    <!-- Swiper Init -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            new Swiper(".myAdBannerSwiper", {
                slidesPerView: 1,
                spaceBetween: 30,
                loop: true,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false,
                },
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                breakpoints: {
                    768: { slidesPerView: 2 },
                    1200: { slidesPerView: 3 }
                }
            });
        });
    </script>




    <!-- course section start here -->
    <div class="course-section padding-tb section-bg">
        <div class="container">
            <div class="section-header text-center">
                <span class="subtitle" style="color:#ed3532;">Featured Courses</span>
                <h2 class="title" style="color:#1b2954;">Pick A Course To Get Started</h2>
            </div>

            <div class="section-wrapper">
                <div class="row g-4 justify-content-center row-cols-xl-3 row-cols-md-2 row-cols-1">

                    <?php $__empty_1 = true; $__currentLoopData = $featuredCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col">
                        <div class="course-item">
                            <div class="course-inner">
                                <div class="course-thumb">
                                    <img src="<?php echo e(asset($course->image)); ?>" alt="<?php echo e($course->name); ?>" style="height:350px; object-fit:cover;">
                                </div>
                                <div class="course-content">
                                    
                                <div class="course-category d-flex justify-content-between align-items-center">
                                    <div class="course-price-box">
                                        Rs. <?php echo e(number_format($course->total_price, 2)); ?>

                                    </div>

                                    <div class="course-review text-end">
                                        <span class="ratting">
                                            <i class="icofont-ui-rating"></i>
                                            <i class="icofont-ui-rating"></i>
                                            <i class="icofont-ui-rating"></i>
                                            <i class="icofont-ui-rating"></i>
                                            <i class="icofont-ui-rating"></i>
                                        </span>
                                        <span class="ratting-count">4.8</span>
                                    </div>
                                </div>

                                    <a href="<?php echo e(route('frontend.Course', $course->slug)); ?>">
                                        <h5><?php echo e($course->name); ?></h5>
                                    </a>
                                    <div class="course-details">
                                        <div class="couse-count"><i class="icofont-video-alt"></i> <?php echo e($course->duration); ?> Lessons</div>
                                        <div class="couse-topic"><i class="icofont-signal"></i> <?php echo e(ucfirst($course->mode)); ?> Class</div>
                                    </div>
                                    <div class="course-footer">
                                        <div class="course-author">
                                            <a href="#">DSA Academy</a>
                                        </div>
                                        <div class="course-btn">
                                            <a href="<?php echo e(route('frontend.Course', $course->slug)); ?>" class="lab-btn-text">
                                                Read More <i class="icofont-external-link"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">
                            <p>No courses available at the moment.</p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <!-- course section ending here -->


    <!-- VIP Packages Section Start -->
    <div class="course-section padding-tb section-bg">
        <div class="container">
            <div class="section-header text-center">
                <span class="subtitle" style="color:#ed3532;">DSA Special</span>
                <h2 class="title" style="color:#1b2954;">Our VIP Signal Packages</h2>
            </div>

            <div class="section-wrapper">
                <div class="row g-4 justify-content-center row-cols-xl-3 row-cols-md-2 row-cols-1">
                    <?php $__empty_1 = true; $__currentLoopData = $vipPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col">
                            <div class="course-item">
                                <div class="course-inner">
                                    <div class="course-thumb">
                                        <img src="<?php echo e(asset('storage/' . $package->image)); ?>" alt="<?php echo e($package->title); ?>" style="height:350px; object-fit:cover;">
                                    </div>
                                    <div class="course-content">
                                        <!-- Price and Rating Row -->
                                        <div class="course-category d-flex justify-content-between align-items-center">
                                            <div class="course " style="backgroud-color:#000;">
                                                
                                            </div>
                                            <!-- Price and Rating Row -->
                                            <div class="course-category d-flex justify-content-between align-items-center">
                                                <div class="course-price-box">
                                                    Rs. <?php echo e(number_format($package->price, 2)); ?>

                                                </div>
                                                
                                            </div>
                                        </div>

                                        <!-- Title -->
                                        <h5 class="text-truncate"><?php echo e($package->title); ?></h5>

                                        <!-- Description -->
                                        <p><?php echo e(\Illuminate\Support\Str::limit($package->description, 100)); ?></p>

                                        <!-- Footer -->
                                        <div class="course-footer">
                                            <div class="course-author">
                                                <a href="#">DSA Academy</a>
                                            </div>
                                            <div class="course-btn">
                                                <a  class="lab-btn-text">
                                                    Read More <i class="icofont-external-link"></i>
                                                </a>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">
                            <p>No VIP packages available at the moment.</p>
                        </div>
                    <?php endif; ?>
                </div>

                
            </div>
        </div>
    </div>
    <!-- VIP Packages Section End -->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/frontend/Home.blade.php ENDPATH**/ ?>