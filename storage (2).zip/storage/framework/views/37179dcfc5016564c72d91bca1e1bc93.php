

<?php $__env->startSection('title', 'Edit Review'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Edit Review</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.reviews.index')); ?>">Reviews</a></li>
    <li class="breadcrumb-item active">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Error!</strong> Please check the form below.<br><br>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>Edit Review - <?php echo e($review->student_name); ?></h5>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('admin.reviews.update', $review->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row g-3">

                    <div class="col-md-6">
                        <label for="student_name" class="form-label">Student Name</label>
                        <input type="text" name="student_name" class="form-control" value="<?php echo e(old('student_name', $review->student_name)); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="rating" class="form-label">Rating</label>
                        <select name="rating" class="form-control" required>
                            <?php for($i = 5; $i >= 1; $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($review->rating == $i ? 'selected' : ''); ?>>
                                    <?php echo e($i); ?> Star<?php echo e($i > 1 ? 's' : ''); ?>

                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" class="form-control" required>
                            <option value="approved" <?php echo e($review->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                            <option value="pending" <?php echo e($review->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label for="comment" class="form-label">Comment</label>
                        <textarea name="comment" class="form-control" rows="4" required><?php echo e(old('comment', $review->comment)); ?></textarea>
                    </div>

                    <div class="col-12">
                        <label for="image" class="form-label">Upload Image (optional)</label>
                        <input type="file" name="image" class="form-control">
                        <?php if($review->image): ?>
                            <div class="mt-2">
                                <img src="<?php echo e(asset('storage/' . $review->image)); ?>" width="80" class="rounded">
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-12 text-end">
                        <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-secondary">Back</a>
                        <button type="submit" class="btn btn-success">Update Review</button>
                    </div>

                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/reviews/edit.blade.php ENDPATH**/ ?>