<!-- footer start-->
<footer class="footer">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12 footer-copyright text-center">
                <p class="mb-0">Copyright 2025 ©  Esupport Technologies </p>
              </div>
            </div>
          </div>
        </footer><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/footer.blade.php ENDPATH**/ ?>