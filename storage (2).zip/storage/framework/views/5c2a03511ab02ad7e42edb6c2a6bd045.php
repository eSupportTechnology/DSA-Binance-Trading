

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="text-primary fw-bold mb-0"><?php echo e($booking->course->name); ?> – Zoom Links</h4>
        <a href="<?php echo e(route('student.bookings')); ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left-circle"></i> Back to Courses
        </a>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $zoomLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1"><?php echo e($link->week_name); ?></h6>
                        <small class="text-muted"><?php echo e($link->description ?? 'No description provided.'); ?></small>
                    </div>
                    <a href="<?php echo e($link->zoom_link); ?>" target="_blank" class="btn btn-sm btn-outline-info">
                        <i class="bi bi-link-45deg"></i> Join Zoom
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-warning">
            <i class="bi bi-exclamation-circle me-2"></i> No Zoom links available for your batch yet.
        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('StudentDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/StudentDashboard/course/zoom-links.blade.php ENDPATH**/ ?>