

<?php $__env->startSection('title', 'Booking Status - DSA Academy'); ?>

<?php $__env->startSection('content'); ?>
<div class="pageheader-section">
    <div class="container">
        <div class="pageheader-content text-center">
            <h2>Booking Status</h2>
        </div>
    </div>
</div>

<div class="login-section padding-tb section-bg">
    <div class="container text-center">
        <div class="card border-0 shadow-sm p-5 bg-white">
            <?php if($status === 'success'): ?>
                <h2 class="text-success">🎉 Payment Successful!</h2>
                <p><?php echo e($message); ?></p>
            <?php elseif($status === 'pending'): ?>
                <h2 class="text-warning">⏳ Payment Processing...</h2>
                <p><?php echo e($message); ?></p>
                <p>Booking Reference: <strong><?php echo e($reference); ?></strong></p>
                <p class="mt-3">Please wait or refresh this page after a few moments.</p>
            <?php else: ?>
                <h2 class="text-danger">❌ Unable to Confirm Payment</h2>
                <p><?php echo e($message); ?></p>
            <?php endif; ?>
            <a href="<?php echo e(route('frontend.home')); ?>" class="btn btn-primary mt-4">Back to Home</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/frontend/callback.blade.php ENDPATH**/ ?>