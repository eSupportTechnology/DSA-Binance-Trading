

<?php $__env->startSection('title', 'Booking Details'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Booking Details</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Orders</li>
    <li class="breadcrumb-item active">View</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Booking #<?php echo e($booking->id); ?></h5>
            <a href="<?php echo e(route('admin.orders.pending')); ?>" class="btn btn-sm btn-secondary">Back to List</a>
        </div>

        <div class="card-body">
            <h6 class="text-primary mb-3">Student Information</h6>
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><strong>Name:</strong> <?php echo e($booking->customer->name); ?></li>
                <li class="list-group-item"><strong>Email:</strong> <?php echo e($booking->customer->email); ?></li>
                <li class="list-group-item"><strong>Contact:</strong> <?php echo e($booking->customer->contact_number); ?></li>
            </ul>

            <h6 class="text-primary mb-3">Course Information</h6>
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><strong>Course:</strong> <?php echo e($booking->course->name); ?></li>
                <li class="list-group-item"><strong>Location:</strong> <?php echo e($booking->course->location); ?></li>
                <li class="list-group-item"><strong>Mode:</strong> <?php echo e(ucfirst($booking->course->mode)); ?></li>
                <li class="list-group-item"><strong>Duration:</strong> <?php echo e($booking->course->duration); ?> days</li>
            </ul>

            <h6 class="text-primary mb-3">Payment Details</h6>
            <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item"><strong>Status:</strong> <?php echo e($booking->status); ?></li>
                <li class="list-group-item"><strong>Payment Type:</strong> <?php echo e(ucfirst($booking->payment_status)); ?></li>
                <li class="list-group-item"><strong>Method:</strong> <?php echo e($booking->payment_method); ?></li>
                <li class="list-group-item"><strong>Transfer Date:</strong> <?php echo e($booking->transfer_date ?? 'N/A'); ?></li>
                <li class="list-group-item">
                    <strong>Receipt:</strong>
                    <?php if($booking->receipt_path): ?>
                    <a href="<?php echo e(asset('storage/' . $booking->receipt_path)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">View Receipt</a>
                    <?php else: ?>
                        <span class="text-muted">Not Provided</span>
                    <?php endif; ?>
                </li>
            </ul>

            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/orders/show.blade.php ENDPATH**/ ?>