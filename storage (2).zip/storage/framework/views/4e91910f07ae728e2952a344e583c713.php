

<?php $__env->startSection('title', 'Add Ad Banner'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Add New Banner</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.banners.index')); ?>">Ad Banners</a></li>
    <li class="breadcrumb-item active">Create</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Error!</strong> Please check your input.<br><br>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5>New Banner</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.adbanners.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="image" class="form-label">Banner Image <span class="text-danger">*</span></label>
                    <input type="file" name="image" class="form-control" required accept="image/*">
                </div>

                <div class="mb-3">
                    <label for="caption" class="form-label">Caption</label>
                    <input type="text" name="caption" class="form-control" placeholder="E.g. Join our Binance class...">
                </div>

                <div class="text-end">
                    <a href="<?php echo e(route('admin.adbanners.index')); ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-success">Save Banner</button>
                </div>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/adbanners/create.blade.php ENDPATH**/ ?>