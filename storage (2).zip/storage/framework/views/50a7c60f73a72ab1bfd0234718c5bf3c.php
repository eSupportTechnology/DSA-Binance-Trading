

<?php $__env->startSection('title', 'Ad Banners'); ?>

<?php $__env->startSection('breadcrumb-title'); ?>
    <h3>Ad Banners</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb-items'); ?>
    <li class="breadcrumb-item">Settings</li>
    <li class="breadcrumb-item active">Ad Banners</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>All Banners</h5>
            <a href="<?php echo e(route('admin.adbanners.create')); ?>" class="btn btn-primary">+ Add New</a>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Banner</th>
                            <th>Caption</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <?php if($banner->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" alt="Banner" width="100">
                                    <?php else: ?>
                                        <span class="text-muted">No image</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($banner->caption ?? '-'); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($banner->status ? 'success' : 'secondary'); ?>">
                                        <?php echo e($banner->status ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>
                                <td class="d-flex justify-content-center gap-2">
                                    

                                    <form action="<?php echo e(route('admin.adbanners.destroy', $banner->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this banner?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5">No banners available.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('AdminDashboard.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\DSA-Binance-Trading\resources\views/AdminDashboard/adbanners/index.blade.php ENDPATH**/ ?>